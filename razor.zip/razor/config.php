<?php
$keyId = 'rzp_test_TT82sxF6m1J8jN';
$keySecret = 'SkT4MwYRkqwSrHz7O610gmxc';
$displayCurrency = 'INR';
$link = mysqli_connect('localhost', 'qacxdneq_influencer', '@$EvFW78U+VY', 'qacxdneq_influencerhire');
if (!$link) {
    die('Could not connect: ' . mysql_error());
}
error_reporting(E_ALL);
ini_set('display_errors', 1);
